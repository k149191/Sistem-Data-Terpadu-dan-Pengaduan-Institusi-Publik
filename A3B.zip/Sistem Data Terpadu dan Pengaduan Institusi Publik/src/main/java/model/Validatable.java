package model;

public interface Validatable {
    void validate();
}
