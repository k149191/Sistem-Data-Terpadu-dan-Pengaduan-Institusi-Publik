package model;

public interface Laporan {
    String formatLaporan();
}
